import 'package:flutter/material.dart';

class BotaoPadrao extends StatelessWidget {
  final String texto;
  final VoidCallback aoClicar;

  BotaoPadrao(this.texto, this.aoClicar);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: 8, bottom: 8),
      child: ElevatedButton(
        onPressed: aoClicar,
        child: Text(texto),
      ),
    );
  }
}
