import 'package:flutter/material.dart';

class LinhaInfo extends StatelessWidget {
  final String titulo;
  final String valor;

  LinhaInfo(this.titulo, this.valor);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(titulo),
          Text(valor, style: TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
