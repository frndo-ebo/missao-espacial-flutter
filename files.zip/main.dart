import 'package:flutter/material.dart';
import 'widgets/campo_texto.dart';
import 'widgets/botao_padrao.dart';
import 'widgets/linha_info.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Tela1(),
    );
  }
}

class Tela1 extends StatefulWidget {
  @override
  State<Tela1> createState() => _Tela1State();
}

class _Tela1State extends State<Tela1> {
  TextEditingController nomeC = TextEditingController();
  TextEditingController tripC = TextEditingController();
  TextEditingController distC = TextEditingController();
  String erro = '';

  void avancar() {
    String nome = nomeC.text.trim();
    int tripulantes = int.tryParse(tripC.text) ?? 0;
    double distancia = double.tryParse(distC.text.replaceAll(',', '.')) ?? 0;

    String mensagem = '';
    if (nome == '') {
      mensagem = 'Digite o nome do comandante';
    } else if (tripulantes <= 0) {
      mensagem = 'A quantidade de tripulantes deve ser maior que zero';
    } else if (distancia <= 0) {
      mensagem = 'A distância deve ser maior que zero';
    }

    setState(() {
      erro = mensagem;
    });

    if (mensagem == '') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => Tela2(nome, tripulantes, distancia),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Configuração da Missão')),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              CampoTexto('Nome do Comandante', nomeC),
              CampoTexto('Quantidade de Tripulantes', tripC),
              CampoTexto('Distância do Destino (anos-luz)', distC),
              Text(erro, style: TextStyle(color: Colors.red)),
              BotaoPadrao('Avançar para Recursos', avancar),
            ],
          ),
        ),
      ),
    );
  }
}

class Tela2 extends StatefulWidget {
  final String nome;
  final int tripulantes;
  final double distancia;

  Tela2(this.nome, this.tripulantes, this.distancia);

  @override
  State<Tela2> createState() => _Tela2State();
}

class _Tela2State extends State<Tela2> {
  TextEditingController diasC = TextEditingController();
  TextEditingController custoC = TextEditingController();
  String erro = '';
  bool calculado = false;
  int dias = 0;
  double custoCombustivel = 0;
  double custoOxigenio = 0;
  double orcamentoTotal = 0;

  void calcular() {
    double custoKg = double.tryParse(custoC.text.replaceAll(',', '.')) ?? 0;

    setState(() {
      dias = int.tryParse(diasC.text) ?? 0;
      calculado = false;

      if (dias <= 0) {
        erro = 'Os dias devem ser maiores que zero';
      } else if (custoKg <= 0) {
        erro = 'O custo por quilo deve ser maior que zero';
      } else {
        erro = '';
        double combustivelTotal = (widget.distancia * widget.tripulantes) * 1000;
        custoCombustivel = combustivelTotal * custoKg;
        double racaoOxigenio = widget.tripulantes * dias * 2.5;
        custoOxigenio = racaoOxigenio * 50;
        orcamentoTotal = custoCombustivel + custoOxigenio;
        calculado = true;
      }
    });
  }

  void avancar() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Tela3(
          widget.nome,
          widget.tripulantes,
          widget.distancia,
          dias,
          custoCombustivel,
          custoOxigenio,
          orcamentoTotal,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Recursos e Suprimentos')),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              CampoTexto('Dias estimados para a viagem', diasC),
              CampoTexto('Custo por kg de combustível (USD)', custoC),
              Text(erro, style: TextStyle(color: Colors.red)),
              BotaoPadrao('Calcular', calcular),
              if (calculado)
                Column(
                  children: [
                    LinhaInfo('Custo do combustível', '${custoCombustivel.toStringAsFixed(2)} USD'),
                    LinhaInfo('Custo do oxigênio', '${custoOxigenio.toStringAsFixed(2)} USD'),
                    LinhaInfo('Orçamento total', '${orcamentoTotal.toStringAsFixed(2)} USD'),
                    BotaoPadrao('Avançar para Risco', avancar),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class Tela3 extends StatefulWidget {
  final String nome;
  final int tripulantes;
  final double distancia;
  final int dias;
  final double custoCombustivel;
  final double custoOxigenio;
  final double orcamentoTotal;

  Tela3(
    this.nome,
    this.tripulantes,
    this.distancia,
    this.dias,
    this.custoCombustivel,
    this.custoOxigenio,
    this.orcamentoTotal,
  );

  @override
  State<Tela3> createState() => _Tela3State();
}

class _Tela3State extends State<Tela3> {
  TextEditingController orcC = TextEditingController();
  TextEditingController velC = TextEditingController();
  String erro = '';
  bool calculado = false;
  double orcamentoDisponivel = 0;
  double velocidade = 0;
  double saldoFinal = 0;
  double desgaste = 0;
  bool pane = false;

  void calcular() {
    setState(() {
      orcamentoDisponivel = double.tryParse(orcC.text.replaceAll(',', '.')) ?? 0;
      velocidade = double.tryParse(velC.text.replaceAll(',', '.')) ?? 0;
      calculado = false;

      if (orcamentoDisponivel <= 0) {
        erro = 'O orçamento disponível deve ser maior que zero';
      } else if (velocidade < 1 || velocidade > 100) {
        erro = 'A velocidade deve estar entre 1 e 100';
      } else {
        erro = '';
        saldoFinal = orcamentoDisponivel - widget.orcamentoTotal;
        desgaste = (velocidade / 10) * widget.dias;
        pane = velocidade > 80;
        calculado = true;
      }
    });
  }

  void avancar() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Tela4(
          widget.nome,
          widget.tripulantes,
          widget.distancia,
          widget.dias,
          widget.custoCombustivel,
          widget.custoOxigenio,
          widget.orcamentoTotal,
          orcamentoDisponivel,
          saldoFinal,
          velocidade,
          desgaste,
          pane,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Risco e Motores')),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              CampoTexto('Orçamento disponível em caixa (USD)', orcC),
              CampoTexto('Velocidade dos motores (1 a 100 %)', velC),
              Text(erro, style: TextStyle(color: Colors.red)),
              BotaoPadrao('Calcular', calcular),
              if (calculado)
                Column(
                  children: [
                    Text(
                      'Saldo final: ${saldoFinal.toStringAsFixed(2)} USD',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: saldoFinal < 0 ? Colors.red : Colors.black,
                      ),
                    ),
                    if (saldoFinal < 0)
                      Text(
                        'Risco Crítico de Falência Financeira',
                        style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
                      ),
                    LinhaInfo('Fator de desgaste', desgaste.toStringAsFixed(2)),
                    if (pane)
                      Text(
                        'ALERTA: alta probabilidade de pane nos motores',
                        style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold),
                      ),
                    BotaoPadrao('Ver Relatório Final', avancar),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class Tela4 extends StatelessWidget {
  final String nome;
  final int tripulantes;
  final double distancia;
  final int dias;
  final double custoCombustivel;
  final double custoOxigenio;
  final double orcamentoTotal;
  final double orcamentoDisponivel;
  final double saldoFinal;
  final double velocidade;
  final double desgaste;
  final bool pane;

  Tela4(
    this.nome,
    this.tripulantes,
    this.distancia,
    this.dias,
    this.custoCombustivel,
    this.custoOxigenio,
    this.orcamentoTotal,
    this.orcamentoDisponivel,
    this.saldoFinal,
    this.velocidade,
    this.desgaste,
    this.pane,
  );

  @override
  Widget build(BuildContext context) {
    String status;
    if (saldoFinal >= 0 && velocidade <= 80) {
      status = 'Missão Concluída com Sucesso';
    } else {
      status = 'Missão Resgatada com Avarias';
    }

    return Scaffold(
      appBar: AppBar(title: Text('Relatório Final')),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Comandante $nome',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              Text('Tripulação: $tripulantes pessoas'),
              SizedBox(height: 24),
              Text('Rota', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              LinhaInfo('Distância', '$distancia anos-luz'),
              LinhaInfo('Dias estimados', '$dias dias'),
              SizedBox(height: 24),
              Text('Finanças', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              LinhaInfo('Combustível', '${custoCombustivel.toStringAsFixed(2)} USD'),
              LinhaInfo('Oxigênio', '${custoOxigenio.toStringAsFixed(2)} USD'),
              LinhaInfo('Orçamento total', '${orcamentoTotal.toStringAsFixed(2)} USD'),
              LinhaInfo('Orçamento disponível', '${orcamentoDisponivel.toStringAsFixed(2)} USD'),
              LinhaInfo('Saldo final em caixa', '${saldoFinal.toStringAsFixed(2)} USD'),
              SizedBox(height: 24),
              Text('Motores', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              LinhaInfo('Velocidade', '$velocidade %'),
              LinhaInfo('Fator de desgaste', desgaste.toStringAsFixed(2)),
              LinhaInfo('Alerta de pane', pane ? 'Sim' : 'Não'),
              SizedBox(height: 24),
              Center(
                child: Text(
                  status,
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(height: 16),
              Center(
                child: BotaoPadrao('Reiniciar Missão', () {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => Tela1()),
                    (rota) => false,
                  );
                }),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
