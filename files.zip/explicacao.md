# Explicação do código – Simulador de Missão Intergaláctica

## Ideia geral (diga isso primeiro ao professor)

O app tem **4 telas**. Cada tela pede alguns dados, faz contas e **passa tudo para a próxima tela pelo construtor**. Para não repetir código, criei **3 widgets reutilizáveis** em arquivos separados, que uso nas telas.

```
lib/
  main.dart                  -> MyApp e as 4 telas
  widgets/
    campo_texto.dart         -> CampoTexto
    botao_padrao.dart        -> BotaoPadrao
    linha_info.dart          -> LinhaInfo
```

Comparando com React:
- cada widget é como um **componente**;
- os parâmetros do construtor são as **props**;
- o `import` no topo do `main.dart` é igual ao `import` de componentes;
- o `setState` faz o papel do `useState`.

---

## Conceitos usados

| Conceito | O que é | Onde aparece |
|---|---|---|
| `StatelessWidget` | Widget que **não muda** depois de desenhado | MyApp, Tela4 e os 3 widgets reutilizáveis |
| `StatefulWidget` | Widget que **muda** (resultados, mensagens de erro) | Tela1, Tela2, Tela3 |
| `setState` | Avisa o Flutter: "mudei variáveis, redesenhe a tela" | `avancar()` e `calcular()` |
| `TextEditingController` | Guarda o que o usuário digitou no campo | `nomeC`, `tripC`, `distC`... |
| `Navigator.push` | Abre uma nova tela por cima da atual | Botões de avançar |
| `Navigator.pushAndRemoveUntil` | Abre uma tela e **apaga o histórico** | Botão Reiniciar |
| Construtor | Forma de enviar dados de uma tela para outra | `Tela2(nome, tripulantes, distancia)` |
| `widget.` | Dentro do State, acessa os dados recebidos pelo construtor | `widget.distancia` |

---

## Parte por parte

### 1. `main()` e `MyApp`

```dart
void main() {
  runApp(MyApp());
}
```
É onde o app começa. `runApp` liga o app e mostra o `MyApp`.

`MyApp` devolve um `MaterialApp`, que é a "casca" do app. Em `home:` indica a **primeira tela**: `Tela1()`. O `debugShowCheckedModeBanner: false` só tira a faixa "DEBUG" do canto.

---

### 2. Widgets reutilizáveis (pedido do professor)

Cada um fica em `lib/widgets/` e o `main.dart` importa os três:
```dart
import 'widgets/campo_texto.dart';
import 'widgets/botao_padrao.dart';
import 'widgets/linha_info.dart';
```
Cada arquivo também importa `package:flutter/material.dart`, porque usa os widgets do Flutter.

Os três recebem os dados **por posição**, na ordem do construtor. Exemplo: `CampoTexto('Nome do Comandante', nomeC)`.

#### `CampoTexto(rotulo, controlador)`
Um campo de digitação pronto. O `rotulo` é o texto que aparece no campo e o `controlador` guarda o que foi digitado. Por dentro é um `TextField` com `InputDecoration` (rótulo e borda). Usado 3 vezes na Tela 1, 2 na Tela 2 e 2 na Tela 3: **7 vezes com um único código**.

#### `BotaoPadrao(texto, aoClicar)`
Um botão (`ElevatedButton`). Recebe o `texto` e a função `aoClicar` (tipo `VoidCallback`: uma função sem parâmetros e sem retorno). Usado em todas as telas.

#### `LinhaInfo(titulo, valor)`
Mostra uma linha "título ........ valor" usando um `Row` com `spaceBetween` (um texto em cada ponta). O valor fica em negrito. Usado nas telas 2, 3 e 4.

O `Padding` que aparece nos três só dá um espaçamento.

---

### 3. Tela 1 – Configuração

**Variáveis:**
- `nomeC`, `tripC`, `distC`: controladores dos 3 campos;
- `erro`: texto da mensagem de erro (começa vazio).

**`avancar()`:**
1. Lê o que foi digitado com `.text`.
2. Converte para número com `int.tryParse` / `double.tryParse`. O `?? 0` quer dizer: "se não conseguir converter (campo vazio ou letras), use 0".
3. O `replaceAll(',', '.')` troca vírgula por ponto, porque o Dart só entende ponto nos decimais.
4. Os `if / else if` descobrem qual é o primeiro erro (nome vazio, tripulantes <= 0 ou distância <= 0) e guardam a frase em `mensagem`.
5. O `setState` coloca a mensagem em `erro`, e ela aparece em vermelho na tela.
6. Se `mensagem == ''` (nenhum erro), faz o `Navigator.push` para a `Tela2`, enviando nome, tripulantes e distância.

**`build`:** monta a tela com:
- `Scaffold`: estrutura da tela;
- `AppBar`: barra de cima;
- `SingleChildScrollView`: permite rolar se faltar espaço;
- `Padding`: margem;
- `Column`: itens um embaixo do outro.

---

### 4. Tela 2 – Recursos

**Recebe** pelo construtor: `nome`, `tripulantes`, `distancia`. A linha `Tela2(this.nome, this.tripulantes, this.distancia);` guarda esses valores nas variáveis `final` da classe.

**Variáveis do State:** controladores, `erro`, `dias`, os custos e o `orcamentoTotal`. A variável `calculado` (bool) controla se os resultados já aparecem.

**`calcular()`:** valida dias e custo (maiores que zero). Se estiver certo, faz as contas:
- Combustível total = (distância × tripulantes) × 1000
- Custo do combustível = combustível total × custo por kg
- Ração de oxigênio = tripulantes × dias × 2.5
- Custo do oxigênio = ração × 50
- Orçamento total = custo do combustível + custo do oxigênio

Os dados da tela anterior são acessados com `widget.distancia` e `widget.tripulantes`.

**`if (calculado)` na lista de widgets:** só mostra os resultados e o botão "Avançar para Risco" depois que o cálculo deu certo.

**`avancar()`:** `Navigator.push` para a `Tela3`, enviando os dados recebidos e os novos (`dias`, custos e orçamento total).

`toStringAsFixed(2)` mostra o número com 2 casas decimais.

---

### 5. Tela 3 – Risco e motores

**Recebe:** nome, tripulantes, distância, dias, custo do combustível, custo do oxigênio e orçamento total.

**Entradas novas:** orçamento disponível e velocidade (validada de 1 a 100).

**Contas em `calcular()`:**
- `saldoFinal = orcamentoDisponivel - widget.orcamentoTotal` (pode ficar negativo);
- `desgaste = (velocidade / 10) * widget.dias`;
- `pane = velocidade > 80` (um `bool`, que funciona como a "flag" de alerta).

**Visual:**
- `color: saldoFinal < 0 ? Colors.red : Colors.black` deixa o saldo vermelho se for negativo;
- `if (saldoFinal < 0)` mostra "Risco Crítico de Falência Financeira";
- `if (pane)` mostra o alerta de pane em laranja.

**`avancar()`:** envia **todas** as variáveis para a `Tela4`.

---

### 6. Tela 4 – Relatório final

É `StatelessWidget` porque **só mostra dados**. As 12 variáveis chegam pelo construtor, **na ordem em que foram declaradas**.

**Status final** (lógica escolhida por mim, como o professor permitiu):
```
se saldoFinal >= 0 E velocidade <= 80  -> "Missão Concluída com Sucesso"
senão                                  -> "Missão Resgatada com Avarias"
```

**Tela:** usa `Text` para o cabeçalho e os títulos, e `LinhaInfo` para cada linha do relatório. `$nome` dentro de um texto coloca o valor da variável na frase. `pane ? 'Sim' : 'Não'` escolhe o texto conforme o valor.

**Botão Reiniciar:** chama `Navigator.pushAndRemoveUntil`. Ele abre a `Tela1` e a regra `(rota) => false` **apaga todas as telas anteriores**. Assim o botão voltar do celular não volta para as telas antigas.

---

## Perguntas que o professor pode fazer

**Qual a diferença entre Stateless e Stateful?**
Stateless não muda depois de criado. Stateful tem variáveis que mudam e a tela é atualizada com `setState`.

**Para que serve o `setState`?**
Avisa o Flutter que as variáveis mudaram, para ele redesenhar a tela com os novos valores.

**Como os dados passam de uma tela para outra?**
Pelo construtor. No `Navigator.push`, crio a próxima tela já passando os valores (`Tela2(nome, tripulantes, distancia)`).

**Para que serve o `widget.` nas telas Stateful?**
O State é uma classe separada da tela. Com `widget.` ele acessa os dados que a tela recebeu pelo construtor.

**O que é o `TextEditingController`?**
Guarda o texto digitado no campo. Com `.text` eu leio o valor.

**Qual a diferença entre `push` e `pushAndRemoveUntil`?**
`push` empilha uma tela mantendo as anteriores. `pushAndRemoveUntil` empilha e remove as anteriores conforme a regra; com `false` remove todas.

**Onde está a reutilização de widgets?**
`CampoTexto`, `BotaoPadrao` e `LinhaInfo`, cada um em seu arquivo em `lib/widgets/`, usados em várias telas, como componentes do React.

**Para que serve `?? 0`?**
Se a conversão do texto para número falhar, usa 0. Aí a validação pega o erro.

**O que é `final`?**
Variável que recebe o valor uma vez e não muda mais. Os dados recebidos pelo construtor são `final`.

**O que é o `build`?**
O método que desenha o widget na tela.

---

## Como rodar

1. Crie um projeto: `flutter create missao_intergalactica`
2. Substitua o conteúdo de `lib/main.dart` por este `main.dart`.
3. Crie a pasta `lib/widgets/` e coloque dentro os 3 arquivos: `campo_texto.dart`, `botao_padrao.dart` e `linha_info.dart`.
4. Rode com `flutter run`.

Dica para testar: Tripulantes 3, Distância 2, Dias 10, Custo 5 → custo do combustível = 30000 USD, oxigênio = 3750 USD, orçamento total = 33750 USD.
