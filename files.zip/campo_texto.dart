import 'package:flutter/material.dart';

class CampoTexto extends StatelessWidget {
  final String rotulo;
  final TextEditingController controlador;

  CampoTexto(this.rotulo, this.controlador);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controlador,
        decoration: InputDecoration(
          labelText: rotulo,
          border: OutlineInputBorder(),
        ),
      ),
    );
  }
}
